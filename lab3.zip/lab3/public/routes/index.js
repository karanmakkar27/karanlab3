var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/Bharat', function(req, res, next) {
  res.render('Bharat', { title: 'Express' });
});

router.get('/Jahnavi', function(req, res, next) {
  res.render('Jahnavi', { title: 'Express' });
});

router.get('/Kiran', function(req, res, next) {
  res.render('Kiran', { title: 'Express' });
});

module.exports = router;
